package com.example.thesuerplus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog

class RestaurantDetailActivity : AppCompatActivity() {

    private lateinit var restaurant: Restaurant
    private val TAG = "RestaurantDetailActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurant_detail)
        Log.d(TAG, "onCreate: Iniciando RestaurantDetailActivity")

        val restaurantExtra = intent.getSerializableExtra("RESTAURANT")
        if (restaurantExtra == null) {
            Log.e(TAG, "Error: No se recibió el restaurante en el intent")
            Toast.makeText(this, "Error al cargar el restaurante", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        try {
            restaurant = restaurantExtra as Restaurant
            Log.d(TAG, "Restaurante recibido: ${restaurant.name}")
        } catch (e: ClassCastException) {
            Log.e(TAG, "Error de casteo: ${e.message}")
            Toast.makeText(this, "Error en los datos del restaurante", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        ShoppingCartManager.switchToRestaurant(restaurant.id, restaurant.name)

        setupToolbar()
        displayRestaurantInfo()
        displayPacks()
        setupCartButton()
        updateCartSummary()
    }

    private fun setupToolbar() {
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish()  // Regresa a HomeActivity
        }
    }

    private fun displayRestaurantInfo() {
        // Nombre restaurante
        findViewById<TextView>(R.id.restaurantName).text = restaurant.name

        val infoText = "⭐ ${restaurant.rating} (${restaurant.reviewCount}) • 🛵 ${restaurant.distance} • 🍽️ ${restaurant.type}"
        findViewById<TextView>(R.id.restaurantInfo).text = infoText

        // Dirección
        findViewById<TextView>(R.id.restaurantAddress).text = restaurant.address

        // Imagen
        val restaurantImage = findViewById<ImageView>(R.id.restaurantImage)
        restaurantImage.setImageResource(restaurant.imageRes)

        Log.d(TAG, "Información del restaurante mostrada: ${restaurant.name}")
    }

    private fun displayPacks() {
        val packsContainer = findViewById<LinearLayout>(R.id.packsContainer)
        packsContainer.removeAllViews()

        if (restaurant.packs.isEmpty()) {
            Log.d(TAG, "El restaurante no tiene packs disponibles")
            val emptyView = TextView(this).apply {
                text = "No hay packs disponibles en este momento"
                setTextColor(resources.getColor(android.R.color.darker_gray))
                textSize = 16f
                gravity = android.view.Gravity.CENTER
                setPadding(0, 32, 0, 0)
            }
            packsContainer.addView(emptyView)
            return
        }

        restaurant.packs.forEach { pack ->
            val packView = LayoutInflater.from(this).inflate(R.layout.item_pack, packsContainer, false)

            val packImage = packView.findViewById<ImageView>(R.id.packImage)
            val packName = packView.findViewById<TextView>(R.id.packName)
            val packDescription = packView.findViewById<TextView>(R.id.packDescription)
            val packContents = packView.findViewById<TextView>(R.id.packContents)
            val packPrice = packView.findViewById<TextView>(R.id.packPrice)
            val packAvailability = packView.findViewById<TextView>(R.id.packAvailability)
            val packPickupTime = packView.findViewById<TextView>(R.id.packPickupTime)
            val quantityText = packView.findViewById<TextView>(R.id.quantityText)
            val decreaseButton = packView.findViewById<TextView>(R.id.decreaseButton)
            val increaseButton = packView.findViewById<TextView>(R.id.increaseButton)
            val addToCartButton = packView.findViewById<TextView>(R.id.addToCartButton)


            packImage.setImageResource(pack.imageRes)
            packName.text = pack.name
            packDescription.text = pack.description

            val contentsText = "Contiene: " + pack.contents.joinToString(", ")
            packContents.text = contentsText

            packPrice.text = "~~$${pack.originalPrice.toInt()}~~ $${pack.discountPrice.toInt()} (${pack.discountPercentage}% OFF)"

            packAvailability.text = "🎁 ${pack.availableQuantity} disponibles"

            packPickupTime.text = "⏰ ${pack.pickupWindow}"

            var quantity = 1
            quantityText.text = quantity.toString()

            decreaseButton.setOnClickListener {
                if (quantity > 1) {
                    quantity--
                    quantityText.text = quantity.toString()
                }
            }

            increaseButton.setOnClickListener {
                if (quantity < pack.availableQuantity) {
                    quantity++
                    quantityText.text = quantity.toString()
                } else {
                    Toast.makeText(this, "No hay más unidades disponibles", Toast.LENGTH_SHORT).show()
                }
            }

            // Agregar al carrito
            addToCartButton.setOnClickListener {
                // Verificar si hay items de otro restaurante
                val currentCart = ShoppingCartManager.getCurrentCart()
                if (currentCart != null && currentCart.restaurantId != restaurant.id) {
                    // Mostrar diálogo de confirmación
                    showRestaurantChangeDialog(pack, quantity)
                } else {
                    addItemToCart(pack, quantity)
                    quantity = 1
                    quantityText.text = "1"
                }
            }

            packsContainer.addView(packView)
        }

        Log.d(TAG, "Packs mostrados: ${restaurant.packs.size}")
    }

    private fun showRestaurantChangeDialog(pack: Pack, quantity: Int) {
        AlertDialog.Builder(this)
            .setTitle("Cambiar de restaurante")
            .setMessage("Tienes items de otro restaurante en tu carrito. ¿Deseas limpiar el carrito y agregar items de ${restaurant.name}?")
            .setPositiveButton("Sí, cambiar") { dialog, _ ->
                // Limpiar carrito anterior
                ShoppingCartManager.clearCurrentCart()
                ShoppingCartManager.switchToRestaurant(restaurant.id, restaurant.name)
                addItemToCart(pack, quantity)
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun addItemToCart(pack: Pack, quantity: Int) {
        val cartItem = CartItem(
            restaurantId = restaurant.id,
            restaurantName = restaurant.name,
            packId = pack.id,
            packName = pack.name,
            quantity = quantity,
            unitPrice = pack.discountPrice,
            pickupWindow = pack.pickupWindow,
            packContents = pack.contents,
            packImageRes = pack.imageRes
        )

        ShoppingCartManager.addItemToCurrentCart(cartItem)
        updateCartSummary()

        Toast.makeText(
            this,
            "${quantity}x ${pack.name} agregado al carrito de ${restaurant.name}",
            Toast.LENGTH_SHORT
        ).show()

        Log.d(TAG, "Item agregado al carrito: ${pack.name} x$quantity")
    }

    private fun updateCartSummary() {
        val cartSummary = findViewById<TextView>(R.id.cartSummary)
        val cartTotal = findViewById<TextView>(R.id.cartTotal)

        val currentCart = ShoppingCartManager.getCurrentCart()

        if (currentCart != null && currentCart.itemCount > 0) {
            cartSummary.text = "Carrito (${restaurant.name}): ${currentCart.itemCount} items"
            cartTotal.text = "Total: $${String.format("%.2f", currentCart.totalPrice)}"
        } else {
            cartSummary.text = "Carrito vacío"
            cartTotal.text = "Agrega items"
        }
    }

    private fun setupCartButton() {
        val viewCartButton = findViewById<TextView>(R.id.viewCartButton)
        viewCartButton.setOnClickListener {
            val currentCart = ShoppingCartManager.getCurrentCart()

            if (currentCart != null && currentCart.itemCount > 0) {
                val intent = Intent(this, CartActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateCartSummary()
    }
}