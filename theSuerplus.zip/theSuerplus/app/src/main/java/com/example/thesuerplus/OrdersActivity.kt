package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import android.os.Build
import androidx.core.content.ContextCompat
import android.view.WindowManager

class OrdersActivity : AppCompatActivity() {

    private lateinit var ordersRecyclerView: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var ordersAdapter: OrdersAdapter
    private var ordersList = mutableListOf<Order>()
    private var selectedFilter: String = "all"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Configurar Status Bar
        window.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@OrdersActivity, R.color.primary_dark)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        setContentView(R.layout.activity_orders)

        setupToolbar()
        setupViews()
        loadOrders()
        setupBottomNavigation()
        setupFilterButtons()
    }

    private fun setupToolbar() {
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        val filterButton = findViewById<ImageView>(R.id.filterButton)
        filterButton.setOnClickListener {
            showFilterDialog()
        }
    }

    private fun setupViews() {
        ordersRecyclerView = findViewById(R.id.ordersRecyclerView)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)

        // Configurar RecyclerView
        ordersRecyclerView.layoutManager = LinearLayoutManager(this)
        ordersAdapter = OrdersAdapter(ordersList) { order ->
            // Click en orden - mostrar detalles
            showOrderDetails(order)
        }

        ordersRecyclerView.adapter = ordersAdapter

        // Botón para seguir explorando
        findViewById<TextView>(R.id.exploreButton).setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }
    }

    private fun setupFilterButtons() {
        val allButton = findViewById<TextView>(R.id.filterAll)
        val pendingButton = findViewById<TextView>(R.id.filterPending)
        val completedButton = findViewById<TextView>(R.id.filterCompleted)

        allButton.setOnClickListener {
            selectedFilter = "all"
            updateFilterButtons()
            loadOrders()
        }

        pendingButton.setOnClickListener {
            selectedFilter = "pending"
            updateFilterButtons()
            loadOrders()
        }

        completedButton.setOnClickListener {
            selectedFilter = "completed"
            updateFilterButtons()
            loadOrders()
        }
    }

    private fun updateFilterButtons() {
        val allButton = findViewById<TextView>(R.id.filterAll)
        val pendingButton = findViewById<TextView>(R.id.filterPending)
        val completedButton = findViewById<TextView>(R.id.filterCompleted)

        val selectedColor = ContextCompat.getColor(this, R.color.primary_dark)
        val unselectedColor = ContextCompat.getColor(this, R.color.gray)

        allButton.setTextColor(if (selectedFilter == "all") selectedColor else unselectedColor)
        pendingButton.setTextColor(if (selectedFilter == "pending") selectedColor else unselectedColor)
        completedButton.setTextColor(if (selectedFilter == "completed") selectedColor else unselectedColor)
    }

    fun loadOrders() {
        ordersList.clear()
        val allOrders = OrdersManager.getOrders(this)

        when (selectedFilter) {
            "all" -> ordersList.addAll(allOrders)
            "pending" -> ordersList.addAll(allOrders.filter {
                it.status == OrderStatus.PENDING ||
                        it.status == OrderStatus.CONFIRMED ||
                        it.status == OrderStatus.PREPARING
            })
            "completed" -> ordersList.addAll(allOrders.filter {
                it.status == OrderStatus.READY ||
                        it.status == OrderStatus.COMPLETED
            })
        }

        // Ordenar por fecha (más reciente primero)
        ordersList.sortByDescending { it.orderDate }

        if (ordersList.isEmpty()) {
            ordersRecyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            ordersRecyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
            findViewById<TextView>(R.id.ordersCount).text = "${ordersList.size} órdenes"
        }

        ordersAdapter.notifyDataSetChanged()
    }

    private fun showFilterDialog() {
        val filterOptions = arrayOf("Todas", "Pendientes", "En preparación", "Listas", "Completadas", "Canceladas")

        AlertDialog.Builder(this)
            .setTitle("Filtrar órdenes")
            .setItems(filterOptions) { dialog, which ->
                val selectedFilter = filterOptions[which]

                ordersList.clear()
                val allOrders = OrdersManager.getOrders(this)

                when (which) {
                    0 -> ordersList.addAll(allOrders)
                    1 -> ordersList.addAll(allOrders.filter { it.status == OrderStatus.PENDING })
                    2 -> ordersList.addAll(allOrders.filter { it.status == OrderStatus.PREPARING })
                    3 -> ordersList.addAll(allOrders.filter { it.status == OrderStatus.READY })
                    4 -> ordersList.addAll(allOrders.filter { it.status == OrderStatus.COMPLETED })
                    5 -> ordersList.addAll(allOrders.filter { it.status == OrderStatus.CANCELLED })
                }

                ordersList.sortByDescending { it.orderDate }
                ordersAdapter.notifyDataSetChanged()
                Toast.makeText(this, "Filtro: $selectedFilter", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showOrderDetails(order: Order) {
        val itemsText = order.items.joinToString("\n") { item ->
            "  • ${item.quantity}x ${item.name} - $${item.total}"
        }

        val statusColor = when (order.status) {
            OrderStatus.PENDING -> "#FFA726" // Naranja
            OrderStatus.CONFIRMED -> "#42A5F5" // Azul
            OrderStatus.PREPARING -> "#66BB6A" // Verde claro
            OrderStatus.READY -> "#4CAF50" // Verde
            OrderStatus.COMPLETED -> "#9E9E9E" // Gris
            OrderStatus.CANCELLED -> "#EF5350" // Rojo
        }

        val message = """
            📋 **Orden #${order.orderNumber}**
            
            🏪 **Restaurante:** ${order.restaurantName}
            📅 **Fecha:** ${order.orderDate}
            ⏰ **Recoger:** ${order.pickupTime}
            💰 **Total:** $${String.format("%.2f", order.totalAmount)}
            💳 **Método:** ${order.paymentMethod}
            
            📦 **Items:**
            $itemsText
            
            🚦 **Estado:** ${order.status.name}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Detalles de la orden")
            .setMessage(message)
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .setNeutralButton("Actualizar estado") { dialog, _ ->
                showUpdateStatusDialog(order)
                dialog.dismiss()
            }
            .show()
    }

    private fun showUpdateStatusDialog(order: Order) {
        val statusOptions = arrayOf("Pendiente", "Confirmado", "En preparación", "Listo", "Completado", "Cancelado")

        AlertDialog.Builder(this)
            .setTitle("Actualizar estado")
            .setItems(statusOptions) { dialog, which ->
                val newStatus = when (which) {
                    0 -> OrderStatus.PENDING
                    1 -> OrderStatus.CONFIRMED
                    2 -> OrderStatus.PREPARING
                    3 -> OrderStatus.READY
                    4 -> OrderStatus.COMPLETED
                    5 -> OrderStatus.CANCELLED
                    else -> OrderStatus.PENDING
                }

                OrdersManager.updateOrderStatus(this, order.orderId, newStatus)
                loadOrders()
                Toast.makeText(this, "Estado actualizado", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun setupBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_orders

        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                    true
                }
                R.id.nav_search -> {
                    // Volver al Home con búsqueda enfocada
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("FOCUS_SEARCH", true)
                    startActivity(intent)
                    true
                }
                R.id.nav_favorites -> {
                    val intent = Intent(this, FavoritesActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_orders -> {
                    // Ya estamos aquí
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadOrders()
    }
}

class OrdersAdapter(
    private val orders: List<Order>,
    private val onItemClick: (Order) -> Unit
) : RecyclerView.Adapter<OrdersAdapter.OrderViewHolder>() {

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        holder.bind(order)

        holder.itemView.setOnClickListener {
            onItemClick(order)
        }
    }

    override fun getItemCount(): Int = orders.size

    class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val orderNumber: TextView = itemView.findViewById(R.id.orderNumber)
        private val restaurantName: TextView = itemView.findViewById(R.id.restaurantName)
        private val orderDate: TextView = itemView.findViewById(R.id.orderDate)
        private val orderTotal: TextView = itemView.findViewById(R.id.orderTotal)
        private val orderStatus: TextView = itemView.findViewById(R.id.orderStatus)

        fun bind(order: Order) {
            orderNumber.text = "Orden #${order.orderNumber}"
            restaurantName.text = order.restaurantName
            orderDate.text = order.orderDate
            orderTotal.text = "$${String.format("%.2f", order.totalAmount)}"
            orderStatus.text = order.status.name

            // Color según el estado
            val color = when (order.status) {
                OrderStatus.PENDING -> android.graphics.Color.parseColor("#FFA726")
                OrderStatus.CONFIRMED -> android.graphics.Color.parseColor("#42A5F5")
                OrderStatus.PREPARING -> android.graphics.Color.parseColor("#66BB6A")
                OrderStatus.READY -> android.graphics.Color.parseColor("#4CAF50")
                OrderStatus.COMPLETED -> android.graphics.Color.parseColor("#9E9E9E")
                OrderStatus.CANCELLED -> android.graphics.Color.parseColor("#EF5350")
            }
            orderStatus.setTextColor(color)
        }
    }
}