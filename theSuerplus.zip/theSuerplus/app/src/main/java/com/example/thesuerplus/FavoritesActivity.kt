package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import android.os.Build
import androidx.core.content.ContextCompat
import android.view.WindowManager

class FavoritesActivity : AppCompatActivity() {

    private lateinit var favoritesRecyclerView: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var favoritesAdapter: FavoritesAdapter
    private var favoritesList = mutableListOf<Restaurant>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.apply {
            // Para Android 5.0+ (API 21+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@FavoritesActivity, R.color.primary_dark)
            }

            // Para Android 6.0+ (íconos claros u oscuros)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        setContentView(R.layout.activity_favorites)

        setupToolbar()
        setupViews()
        loadFavorites()
        setupBottomNavigation()
    }

    private fun setupToolbar() {
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        val clearAllButton = findViewById<TextView>(R.id.clearAllButton)
        clearAllButton.setOnClickListener {
            showClearAllDialog()
        }
    }

    private fun setupViews() {
        favoritesRecyclerView = findViewById(R.id.favoritesRecyclerView)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)

        // Configurar RecyclerView
        favoritesRecyclerView.layoutManager = LinearLayoutManager(this)
        favoritesAdapter = FavoritesAdapter(favoritesList) { restaurant ->
            // Click en restaurante - ir al detalle
            val intent = Intent(this, RestaurantDetailActivity::class.java).apply {
                putExtra("RESTAURANT", restaurant)
            }
            startActivity(intent)
        }

        favoritesRecyclerView.adapter = favoritesAdapter


        findViewById<TextView>(R.id.exploreButton).setOnClickListener {
            finish()
        }
    }

    fun loadFavorites() {
        favoritesList.clear()
        favoritesList.addAll(FavoritesManager.getFavorites(this))

        if (favoritesList.isEmpty()) {

            favoritesRecyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            favoritesRecyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
            findViewById<TextView>(R.id.favoritesCount).text = "${favoritesList.size} favoritos"
        }

        favoritesAdapter.notifyDataSetChanged()
    }

    private fun showClearAllDialog() {
        AlertDialog.Builder(this)
            .setTitle("Eliminar todos los favoritos")
            .setMessage("¿Estás seguro de que quieres eliminar todos tus restaurantes favoritos?")
            .setPositiveButton("Sí, eliminar") { dialog, _ ->
                FavoritesManager.clearFavorites(this)
                loadFavorites()
                Toast.makeText(this, "Todos los favoritos han sido eliminados", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun setupBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_favorites

        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, HomeActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.nav_search -> {
                    val intent = Intent(this, HomeActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        // Opcional: agregar extra para enfocar búsqueda automáticamente
                        putExtra("FOCUS_SEARCH", true)
                    }
                    startActivity(intent)
                    // Cerrar FavoritesActivity
                    finish()
                    true
                }
                R.id.nav_favorites -> {
                    // Ya estamos aquí
                    true
                }
                R.id.nav_orders -> {
                    val intent = Intent(this, OrdersActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }
}
class FavoritesAdapter(
    private val favorites: List<Restaurant>,
    private val onItemClick: (Restaurant) -> Unit
) : RecyclerView.Adapter<FavoritesAdapter.FavoriteViewHolder>() {

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_restaurant, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val restaurant = favorites[position]
        holder.bind(restaurant)

        holder.itemView.setOnClickListener {
            onItemClick(restaurant)
        }
    }

    override fun getItemCount(): Int = favorites.size

    class FavoriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val restaurantImage: ImageView = itemView.findViewById(R.id.restaurantImage)
        private val restaurantName: TextView = itemView.findViewById(R.id.restaurantName)
        private val restaurantType: TextView = itemView.findViewById(R.id.restaurantType)
        private val restaurantRating: TextView = itemView.findViewById(R.id.restaurantRating)
        private val restaurantDistance: TextView = itemView.findViewById(R.id.restaurantDistance)
        private val removeButton: ImageView = itemView.findViewById(R.id.removeButton)

        fun bind(restaurant: Restaurant) {
            restaurantImage.setImageResource(restaurant.imageRes)
            restaurantName.text = restaurant.name
            restaurantType.text = "🍽️ ${restaurant.type}"
            restaurantRating.text = "⭐ ${restaurant.rating} (${restaurant.reviewCount})"
            restaurantDistance.text = "🛵 ${restaurant.distance}"

            removeButton.setOnClickListener {
                FavoritesManager.removeFavorite(itemView.context, restaurant.id)

                Toast.makeText(
                    itemView.context,
                    "${restaurant.name} eliminado de favoritos",
                    Toast.LENGTH_SHORT
                ).show()
                (itemView.context as? FavoritesActivity)?.loadFavorites()
            }
        }
    }
}