package com.example.thesuerplus

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object OrdersManager {
    private const val PREF_NAME = "orders_prefs"
    private const val KEY_ORDERS = "orders_list"
    private val gson = Gson()

    fun placeOrder(context: Context, order: Order) {
        val orders = getOrders(context).toMutableList()
        orders.add(order)
        saveOrders(context, orders)
    }

    fun getOrders(context: Context): List<Order> {
        val sharedPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = sharedPref.getString(KEY_ORDERS, "[]")

        return try {
            val type = object : TypeToken<List<Order>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getOrder(context: Context, orderId: String): Order? {
        return getOrders(context).firstOrNull { it.orderId == orderId }
    }

    fun updateOrderStatus(context: Context, orderId: String, newStatus: OrderStatus) {
        val orders = getOrders(context).toMutableList()
        val index = orders.indexOfFirst { it.orderId == orderId }
        if (index != -1) {
            orders[index] = orders[index].copy(status = newStatus)
            saveOrders(context, orders)
        }
    }

    fun saveOrders(context: Context, orders: List<Order>) {
        val sharedPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = gson.toJson(orders)
        sharedPref.edit().putString(KEY_ORDERS, json).apply()
    }

    // Generar un ID único para la orden
    fun generateOrderId(): String {
        return "ORD_${System.currentTimeMillis()}_${(1000..9999).random()}"
    }
}