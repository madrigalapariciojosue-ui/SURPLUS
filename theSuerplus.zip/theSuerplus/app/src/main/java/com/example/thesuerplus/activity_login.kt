package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import android.os.Build
import androidx.core.content.ContextCompat
import android.view.WindowManager
class activity_login : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private val RC_SIGN_IN = 9001

    private lateinit var googleLoginButton: ImageView
    private lateinit var emailLoginButton: TextView
    private lateinit var phoneLoginButton: TextView
    private lateinit var registerText: TextView
    private lateinit var flechaRegreso: ImageView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.apply {
            // Para Android 5.0+ (API 21+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@activity_login, R.color.primary_dark)
            }

            // Para Android 6.0+ (íconos claros u oscuros)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        setContentView(R.layout.activity_login)

        auth = Firebase.auth
        configurarGoogleSignIn()
        initViews()
        setupListeners()
        verificarUsuarioAutenticado()
    }

    private fun initViews() {
        flechaRegreso = findViewById(R.id.backArrow)
        emailLoginButton = findViewById(R.id.emailLoginButton)
        phoneLoginButton = findViewById(R.id.phoneLoginButton)
        googleLoginButton = findViewById(R.id.googleLoginButton)
        registerText = findViewById(R.id.registerText)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupListeners() {
        flechaRegreso.setOnClickListener {
            finish()
        }

        emailLoginButton.setOnClickListener {
            val intent = Intent(this, sesionCorreo::class.java)
            startActivity(intent)
        }

        phoneLoginButton.setOnClickListener {
            val intent = Intent(this, telefono_login::class.java)
            startActivity(intent)
        }

        googleLoginButton.setOnClickListener {
            iniciarSesionGoogle()
        }

        registerText.setOnClickListener {
            val intent = Intent(this, registro::class.java)
            startActivity(intent)
        }
    }

    private fun configurarGoogleSignIn() {
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build()

            googleSignInClient = GoogleSignIn.getClient(this, gso)
        } catch (e: Exception) {
            Toast.makeText(this,
                "Google Sign-In no configurado. Configura en Firebase Console.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun iniciarSesionGoogle() {
        try {
            val signInIntent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, RC_SIGN_IN)
        } catch (e: Exception) {
            Toast.makeText(this, "Error al iniciar sesión con Google", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                account?.idToken?.let { token ->
                    autenticarConFirebase(token)
                }
            } catch (e: ApiException) {
                when (e.statusCode) {
                    com.google.android.gms.common.ConnectionResult.NETWORK_ERROR -> {
                        Toast.makeText(this, "Error de red. Verifica tu conexión.", Toast.LENGTH_LONG).show()
                    }
                    com.google.android.gms.common.ConnectionResult.SIGN_IN_REQUIRED -> {
                        Toast.makeText(this, "Se requiere iniciar sesión de nuevo", Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        Toast.makeText(this, "Error en Google Sign-In: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun autenticarConFirebase(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)

        googleLoginButton.isClickable = false
        progressBar.visibility = View.VISIBLE

        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                googleLoginButton.isClickable = true
                progressBar.visibility = View.GONE

                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user?.isEmailVerified == true || user?.providerData?.any { it.providerId == "google.com" } == true) {
                        Toast.makeText(this, "¡Inicio de sesión exitoso!", Toast.LENGTH_SHORT).show()
                        redirigirAHomeActivity()
                    } else {
                        Toast.makeText(this, "Por favor, verifica tu email primero", Toast.LENGTH_LONG).show()
                        auth.signOut()
                    }
                } else {
                    Toast.makeText(this, "Error en autenticación con Google", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun verificarUsuarioAutenticado() {
        val currentUser = auth.currentUser
        if (currentUser != null && (currentUser.isEmailVerified || currentUser.providerData.any { it.providerId == "google.com" })) {
            redirigirAHomeActivity()
        }
    }

    private fun redirigirAHomeActivity() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finishAffinity()
    }

    override fun onStart() {
        super.onStart()
        verificarUsuarioAutenticado()
    }
}