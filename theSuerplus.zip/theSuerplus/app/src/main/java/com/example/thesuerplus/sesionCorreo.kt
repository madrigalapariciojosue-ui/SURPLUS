package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import android.os.Build
import android.view.View
import android.view.WindowManager

class sesionCorreo : AppCompatActivity() {
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var passwordVisibility: ImageView
    private lateinit var loginButton: TextView
    private lateinit var forgotPasswordText: TextView
    private lateinit var registerText: TextView
    private lateinit var backArrow: ImageView
    private lateinit var progressBar: ProgressBar

    private var isPasswordVisible = false
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.apply {
            // Para Android 5.0+ (API 21+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@sesionCorreo, R.color.primary_dark)
            }

            // Para Android 6.0+ (íconos claros u oscuros)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        setContentView(R.layout.activity_sesion_correo)

        auth = Firebase.auth

        if (auth.currentUser != null && auth.currentUser?.isEmailVerified == true) {
            redirigirAHomeActivity()
        }

        initViews()
        setupListeners()
    }

    private fun initViews() {
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        passwordVisibility = findViewById(R.id.passwordVisibility)
        loginButton = findViewById(R.id.loginButton)
        forgotPasswordText = findViewById(R.id.forgotPasswordText)
        registerText = findViewById(R.id.registerText)
        backArrow = findViewById(R.id.backArrow)
        progressBar = ProgressBar(this).apply {
            visibility = android.view.View.GONE
        }
    }

    private fun setupListeners() {
        backArrow.setOnClickListener {
            finish()
        }

        passwordVisibility.setOnClickListener {
            togglePasswordVisibility()
        }

        emailEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                validateEmail(s.toString())
            }
        })

        forgotPasswordText.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            if (email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                resetPassword(email)
            } else {
                showEmailDialogForPasswordReset()
            }
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString()

            if (isValidForm(email, password)) {
                iniciarSesion(email, password)
            } else {
                Toast.makeText(this, "Por favor ingresa correo y contraseña válidos", Toast.LENGTH_SHORT).show()
            }
        }

        registerText.setOnClickListener {
            val intent = Intent(this, registro::class.java)
            startActivity(intent)
        }
    }

    private fun togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordEditText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            passwordVisibility.setImageResource(android.R.drawable.ic_menu_view)
        } else {
            passwordEditText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            passwordVisibility.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
        }
        isPasswordVisible = !isPasswordVisible
        passwordEditText.setSelection(passwordEditText.text.length)
    }

    private fun validateEmail(email: String) {
        val isValid = Patterns.EMAIL_ADDRESS.matcher(email).matches()
        if (email.isNotEmpty()) {
            if (isValid) {
                emailEditText.background = ContextCompat.getDrawable(this, R.drawable.edittext_border_valid)
            } else {
                emailEditText.background = ContextCompat.getDrawable(this, R.drawable.edittext_border_error)
            }
        } else {
            emailEditText.background = ContextCompat.getDrawable(this, R.drawable.edittext_border)
        }
    }

    private fun isValidForm(email: String, password: String): Boolean {
        return email.isNotEmpty() &&
                Patterns.EMAIL_ADDRESS.matcher(email).matches() &&
                password.isNotEmpty()
    }

    private fun iniciarSesion(email: String, password: String) {
        loginButton.isClickable = false
        loginButton.text = "Iniciando sesión..."

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                loginButton.isClickable = true
                loginButton.text = "Iniciar sesión"

                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user?.isEmailVerified == true) {
                        Toast.makeText(this, "¡Inicio de sesión exitoso!", Toast.LENGTH_SHORT).show()
                        redirigirAHomeActivity()
                    } else {
                        Toast.makeText(this, "Por favor, verifica tu email primero", Toast.LENGTH_LONG).show()
                        mostrarDialogoVerificacionEmail(user)
                    }
                } else {
                    val errorMessage = when (task.exception?.message) {
                        "The password is invalid or the user does not have a password." ->
                            "Contraseña incorrecta"
                        "There is no user record corresponding to this identifier. The user may have been deleted." ->
                            "No existe una cuenta con este correo"
                        "The email address is badly formatted." ->
                            "Formato de correo inválido"
                        "A network error (such as timeout, interrupted connection or unreachable host) has occurred." ->
                            "Error de red. Verifica tu conexión"
                        else -> "Error: ${task.exception?.message}"
                    }
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun mostrarDialogoVerificacionEmail(user: com.google.firebase.auth.FirebaseUser?) {
        AlertDialog.Builder(this)
            .setTitle("Email no verificado")
            .setMessage("Tu email no ha sido verificado. ¿Quieres que te reenviemos el correo de verificación?")
            .setPositiveButton("Reenviar") { dialog, _ ->
                user?.sendEmailVerification()
                    ?.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Correo de verificación reenviado", Toast.LENGTH_SHORT).show()
                        }
                    }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun resetPassword(email: String) {
        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this,
                        "Se ha enviado un correo para restablecer tu contraseña",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(this,
                        "Error: ${task.exception?.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    private fun showEmailDialogForPasswordReset() {
        val input = EditText(this)
        input.hint = "Ingresa tu correo electrónico"
        input.inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS

        AlertDialog.Builder(this)
            .setTitle("Recuperar contraseña")
            .setMessage("Ingresa tu correo electrónico para restablecer tu contraseña")
            .setView(input)
            .setPositiveButton("Enviar") { dialog, _ ->
                val email = input.text.toString().trim()
                if (email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    resetPassword(email)
                } else {
                    Toast.makeText(this, "Ingresa un correo válido", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun redirigirAHomeActivity() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finishAffinity()
    }
}