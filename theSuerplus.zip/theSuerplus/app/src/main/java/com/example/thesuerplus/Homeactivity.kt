package com.example.thesuerplus

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.IOException
import java.util.*

class HomeActivity : AppCompatActivity() {

    // Variables para ubicación
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var currentLocation: Location? = null
    private var currentAddress: String = "Ciudad de México, MX"

    // Variables para búsqueda y filtrado
    private lateinit var searchEditText: EditText
    private var allRestaurants = mutableListOf<Restaurant>()
    private var filteredRestaurants = mutableListOf<Restaurant>()
    private var currentCategoryFilter: String? = null

    // Constantes para permisos
    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1001
        private const val LOCATION_UPDATE_INTERVAL = 30000L
        private const val LOCATION_FASTEST_UPDATE_INTERVAL = 15000L
        private const val TAG = "HomeActivity"
    }

    // Lista de restaurantes con coordenadas ficticias
    private val restaurants = mutableListOf(
        Restaurant(
            id = "R001",
            name = "Tacos Don José",
            type = "Mexicana",
            rating = 4.5,
            reviewCount = 124,
            distance = "1.2 km",
            imageRes = R.drawable.restaurant_mexican,
            address = "Av. Revolución 456, CDMX",
            latitude = 19.4326,
            longitude = -99.1332,
            generalPickupWindow = "8:00 PM - 8:30 PM",
            packs = listOf(
                Pack(
                    id = "P001",
                    name = "Pack Guisado Tradicional",
                    description = "Guisado del día con acompañamientos",
                    contents = listOf("Pipián de pollo", "Arroz", "Frijoles refritos", "Tortillas de maíz", "Salsa verde"),
                    originalPrice = 180.0,
                    discountPrice = 65.0,
                    availableQuantity = 5,
                    category = "guisados",
                    pickupWindow = "8:00 PM - 8:30 PM",
                    imageRes = R.drawable.pack_guisado
                ),
                Pack(
                    id = "P002",
                    name = "Pack Tacos Variados",
                    description = "Selección de tacos del día",
                    contents = listOf("6 tacos variados (2 pastor, 2 bistec, 2 chorizo)", "Salsa roja", "Salsa verde", "Cebolla", "Cilantro", "Limones"),
                    originalPrice = 120.0,
                    discountPrice = 45.0,
                    availableQuantity = 8,
                    category = "tacos",
                    pickupWindow = "8:30 PM - 9:00 PM",
                    imageRes = R.drawable.pack_tacos
                )
            )
        ),
        Restaurant(
            id = "R002",
            name = "Pizza Napoli",
            type = "Italiana",
            rating = 4.3,
            reviewCount = 89,
            distance = "0.8 km",
            imageRes = R.drawable.restaurant_pizza,
            address = "Calle Roma 123, CDMX",
            latitude = 19.4170,
            longitude = -99.1596,
            generalPickupWindow = "9:00 PM - 9:30 PM",
            packs = listOf(
                Pack(
                    id = "P003",
                    name = "Pack Pizza del Día",
                    description = "Pizza grande con ingredientes frescos",
                    contents = listOf("Pizza grande (margherita o pepperoni)", "Refresco 500ml", "Ajo molido", "Chiles secos"),
                    originalPrice = 250.0,
                    discountPrice = 89.0,
                    availableQuantity = 3,
                    category = "pizza",
                    pickupWindow = "9:00 PM - 9:30 PM",
                    imageRes = R.drawable.pack_pizza
                )
            )
        ),
        Restaurant(
            id = "R003",
            name = "Sushi Express",
            type = "Japonesa",
            rating = 4.7,
            reviewCount = 156,
            distance = "1.5 km",
            imageRes = R.drawable.restaurant_sushi,
            address = "Plaza Miyabi 89, CDMX",
            latitude = 19.4378,
            longitude = -99.1448,
            generalPickupWindow = "8:30 PM - 9:00 PM",
            packs = listOf(
                Pack(
                    id = "P004",
                    name = "Pack Sushi Variado",
                    description = "Combinado de rolls del día",
                    contents = listOf("8 piezas de sushi variado", "Salsa de soya", "Wasabi", "Jengibre", "Té verde"),
                    originalPrice = 320.0,
                    discountPrice = 120.0,
                    availableQuantity = 4,
                    category = "sushi",
                    pickupWindow = "8:30 PM - 9:00 PM",
                    imageRes = R.drawable.sushi_ppack
                )
            )
        ),
        Restaurant(
            id = "R004",
            name = "chef del paste",
            type = "Comida Rápida",
            rating = 4.2,
            reviewCount = 67,
            distance = "0.5 km",
            imageRes = R.drawable.pastes,
            address = "Av. Insurgentes 789, CDMX",
            latitude = 19.4241,
            longitude = -99.1620,
            generalPickupWindow = "7:00 PM - 7:45 PM",
            packs = listOf(
                Pack(
                    id = "P005",
                    name = "Pastes 4 especialidades",
                    description = "pastes ricos compren",
                    contents = listOf("4 pastes de, quueso, italiano, hawalliano,nutella"),
                    originalPrice = 150.0,
                    discountPrice = 55.0,
                    availableQuantity = 7,
                    category = "pastes",
                    pickupWindow = "7:00 PM - 7:45 PM",
                    imageRes = R.drawable.empanadas
                )
            )
        )
    )

    data class FeaturedPack(
        val title: String,
        val description: String,
        val originalPrice: Double,
        val discountPrice: Double,
        val imageRes: Int
    )

    data class Category(
        val emoji: String,
        val name: String
    )

    private val featuredPacks = listOf(
        FeaturedPack("Pack Sorpresa Premium", "Varios restaurantes", 299.0, 99.0, R.drawable.pack_premium),
        FeaturedPack("Pack Postres", "Panadería Dulce", 120.0, 45.0, R.drawable.pack_desserts),
        FeaturedPack("Pack Familiar", "Comida para 4 personas", 450.0, 199.0, R.drawable.pack_family)
    )

    private val categories = listOf(
        Category("🍕", "Todos"),
        Category("🍣", "Asiática"),
        Category("🍔", "Rápida"),
        Category("☕", "Cafés"),
        Category("🍰", "Postres"),
        Category("+", "Más")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homeactivity)
        Log.d(TAG, "onCreate: Iniciando HomeActivity")

        // Inicializar cliente de ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Inicializar listas de restaurantes
        allRestaurants.clear()
        allRestaurants.addAll(restaurants)
        filteredRestaurants.clear()
        filteredRestaurants.addAll(allRestaurants)

        // Configurar ubicación
        setupLocation()

        // Inicio vistas
        initViews()
        setupBottomNavigation()
        setupClickListeners()
    }

    private fun setupLocation() {
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    currentLocation = location
                    updateLocationText(location)
                    updateRestaurantsWithRealDistance()
                }
            }
        }

        //permisos
        if (checkLocationPermission()) {
            startLocationUpdates()
            getLastKnownLocation()
        } else {
            requestLocationPermission()
        }
    }

    private fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    @SuppressLint("MissingPermission")
    private fun getLastKnownLocation() {
        if (checkLocationPermission()) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    location?.let {
                        currentLocation = it
                        updateLocationText(it)
                        updateRestaurantsWithRealDistance()
                    } ?: run {
                        // Si no hay última ubicación, usar ubicación por defecto
                        findViewById<TextView>(R.id.locationText).text = currentAddress
                        displayRestaurants() // Mostrar restaurantes con distancias ficticias
                    }
                }
                .addOnFailureListener { e ->
                    findViewById<TextView>(R.id.locationText).text = currentAddress
                    displayRestaurants()
                    Toast.makeText(this, "No se pudo obtener tu ubicación", Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "Error obteniendo ubicación: ${e.message}")
                }
        } else {
            findViewById<TextView>(R.id.locationText).text = currentAddress
            displayRestaurants()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        if (!checkLocationPermission()) {
            return
        }

        val locationRequest = LocationRequest.create().apply {
            interval = LOCATION_UPDATE_INTERVAL
            fastestInterval = LOCATION_FASTEST_UPDATE_INTERVAL
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    private fun updateLocationText(location: Location) {
        val geocoder = Geocoder(this, Locale.getDefault())

        try {
            val addresses: List<Address> = geocoder.getFromLocation(
                location.latitude,
                location.longitude,
                1
            ) as List<Address>

            if (addresses.isNotEmpty()) {
                val address = addresses[0]
                // Construir dirección legible
                val locality = address.locality ?: ""
                val adminArea = address.adminArea ?: ""
                val subLocality = address.subLocality ?: ""

                currentAddress = if (locality.isNotEmpty()) {
                    if (subLocality.isNotEmpty()) "$subLocality, $locality" else "$locality, $adminArea"
                } else {
                    "📍 Lat: ${String.format("%.4f", location.latitude)}, Lon: ${String.format("%.4f", location.longitude)}"
                }
            } else {
                currentAddress = "📍 ${String.format("%.4f", location.latitude)}, ${String.format("%.4f", location.longitude)}"
            }
        } catch (e: IOException) {
            e.printStackTrace()
            currentAddress = "📍 ${String.format("%.4f", location.latitude)}, ${String.format("%.4f", location.longitude)}"
        }

        findViewById<TextView>(R.id.locationText).text = currentAddress
    }

    private fun updateRestaurantsWithRealDistance() {
        currentLocation?.let { userLocation ->
            restaurants.forEach { restaurant ->
                val distanceInKm = calculateDistance(
                    userLocation.latitude,
                    userLocation.longitude,
                    restaurant.latitude,
                    restaurant.longitude
                )

                // Actualizar la distancia en el objeto restaurante
                restaurant.distance = if (distanceInKm < 1) {
                    "${(distanceInKm * 1000).toInt()} m"
                } else {
                    String.format("%.1f km", distanceInKm)
                }
            }

            displayRestaurants()
        }
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6371.0 // Radio de la Tierra en km

        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)

        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        return earthRadius * c
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permiso c
                    getLastKnownLocation()
                    startLocationUpdates()
                    Toast.makeText(this, "Ubicación activada", Toast.LENGTH_SHORT).show()
                } else {
                    // Permiso d
                    Toast.makeText(this, "Sin permiso de ubicación. Usando ubicación por defecto.", Toast.LENGTH_LONG).show()
                    findViewById<TextView>(R.id.locationText).text = currentAddress
                    displayRestaurants()
                }
            }
        }
    }

    private fun initViews() {
        // Hacer clickable el área de ubicación
        findViewById<LinearLayout>(R.id.locationContainer).setOnClickListener {
            showLocationOptions()
        }

        // Configurar búsqueda
        setupSearch()

        setupCategories()
        setupFeaturedPacks()
        displayRestaurants()
    }

    private fun setupSearch() {
        searchEditText = findViewById(R.id.searchEditText)

        // Configurar TextWatcher para búsqueda en tiempo real
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterRestaurants(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Configurar botón de búsqueda en teclado
        searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                filterRestaurants(searchEditText.text.toString())
                true
            } else {
                false
            }
        }
    }

    private fun filterRestaurants(query: String) {
        val searchQuery = query.trim().lowercase(Locale.getDefault())

        if (searchQuery.isEmpty()) {
            // Si no hay búsqueda, mostrar todos los restaurantes
            filteredRestaurants.clear()
            filteredRestaurants.addAll(allRestaurants)
        } else {
            // Filtrar restaurantes por nombre o tipo
            filteredRestaurants.clear()
            filteredRestaurants.addAll(allRestaurants.filter { restaurant ->
                restaurant.name.lowercase(Locale.getDefault()).contains(searchQuery) ||
                        restaurant.type.lowercase(Locale.getDefault()).contains(searchQuery) ||
                        restaurant.address.lowercase(Locale.getDefault()).contains(searchQuery)
            })
        }

        displayRestaurants()
    }

    private fun setupCategories() {
        val categoriesLayout = findViewById<LinearLayout>(R.id.categoriesLayout)
        categoriesLayout.removeAllViews()

        categories.forEach { category ->
            val categoryView = LayoutInflater.from(this).inflate(R.layout.item_category, categoriesLayout, false)

            val emojiText = categoryView.findViewById<TextView>(R.id.categoryEmoji)
            val nameText = categoryView.findViewById<TextView>(R.id.categoryName)

            emojiText.text = category.emoji
            nameText.text = category.name

            categoryView.setOnClickListener {
                // Filtrar por categoría
                if (category.name == "Todos") {
                    currentCategoryFilter = null
                    filteredRestaurants.clear()
                    filteredRestaurants.addAll(allRestaurants)
                } else {
                    currentCategoryFilter = category.name
                    filteredRestaurants.clear()
                    filteredRestaurants.addAll(allRestaurants.filter {
                        it.type.lowercase(Locale.getDefault()).contains(
                            category.name.lowercase(Locale.getDefault())
                        )
                    })
                }

                // Mantener el filtro de búsqueda si hay texto
                val currentSearch = searchEditText.text.toString()
                if (currentSearch.isNotEmpty()) {
                    filterRestaurants(currentSearch)
                } else {
                    displayRestaurants()
                }

                Toast.makeText(this, "Categoría: ${category.name}", Toast.LENGTH_SHORT).show()
            }

            categoriesLayout.addView(categoryView)
        }
    }

    private fun setupFeaturedPacks() {
        val packsLayout = findViewById<LinearLayout>(R.id.packsLayout)

        featuredPacks.forEach { pack ->
            val packView = LayoutInflater.from(this).inflate(R.layout.item_featured_pack, packsLayout, false)

            val imageView = packView.findViewById<ImageView>(R.id.packImage)
            val titleText = packView.findViewById<TextView>(R.id.packTitle)
            val descText = packView.findViewById<TextView>(R.id.packDescription)
            val priceText = packView.findViewById<TextView>(R.id.packPrice)

            imageView.setImageResource(pack.imageRes)
            titleText.text = pack.title
            descText.text = pack.description
            priceText.text = "$${pack.discountPrice.toInt()}"

            packView.setOnClickListener {
                Toast.makeText(this, "Pack: ${pack.title}", Toast.LENGTH_SHORT).show()
            }

            packsLayout.addView(packView)
        }
    }

    private fun displayRestaurants() {
        val restaurantsLayout = findViewById<LinearLayout>(R.id.restaurantsLayout)
        restaurantsLayout.removeAllViews()

        // Mostrar mensaje si no hay resultados
        if (filteredRestaurants.isEmpty()) {
            val noResultsView = LayoutInflater.from(this).inflate(R.layout.item_no_results, restaurantsLayout, false)

            val messageText = noResultsView.findViewById<TextView>(R.id.ponganmeundiez)
            messageText.text = if (searchEditText.text.isNotEmpty()) {
                "No se encontraron restaurantes para '${searchEditText.text}'"
            } else if (currentCategoryFilter != null) {
                "No hay restaurantes en la categoría '$currentCategoryFilter'"
            } else {
                "No hay restaurantes disponibles"
            }

            restaurantsLayout.addView(noResultsView)
            return
        }

        // Ordenar restaurantes por distancia (si tenemos ubicación real)
        val sortedRestaurants = if (currentLocation != null) {
            filteredRestaurants.sortedBy { restaurant ->
                calculateDistance(
                    currentLocation!!.latitude,
                    currentLocation!!.longitude,
                    restaurant.latitude,
                    restaurant.longitude
                )
            }
        } else {
            filteredRestaurants
        }

        sortedRestaurants.forEach { restaurant ->
            val restaurantView = LayoutInflater.from(this).inflate(R.layout.item_restaurant, restaurantsLayout, false)

            val imageView = restaurantView.findViewById<ImageView>(R.id.restaurantImage)
            val ratingText = restaurantView.findViewById<TextView>(R.id.ratingText)
            val nameText = restaurantView.findViewById<TextView>(R.id.restaurantName)
            val typeText = restaurantView.findViewById<TextView>(R.id.restaurantType)
            val timeText = restaurantView.findViewById<TextView>(R.id.pickupTime)
            val priceText = restaurantView.findViewById<TextView>(R.id.priceText)
            val packsText = restaurantView.findViewById<TextView>(R.id.availablePacks)

            val cheapestPack = restaurant.packs.minByOrNull { it.discountPrice }
            val totalPacks = restaurant.packs.sumOf { it.availableQuantity }

            imageView.setImageResource(restaurant.imageRes)

            val displayDistance = if (currentLocation != null) {
                val distanceInKm = calculateDistance(
                    currentLocation!!.latitude,
                    currentLocation!!.longitude,
                    restaurant.latitude,
                    restaurant.longitude
                )
                if (distanceInKm < 1) {
                    "${(distanceInKm * 1000).toInt()} m"
                } else {
                    String.format("%.1f km", distanceInKm)
                }
            } else {
                restaurant.distance
            }

            ratingText.text = "⭐ ${restaurant.rating} (${restaurant.reviewCount}) • 🛵 $displayDistance"

            nameText.text = restaurant.name
            typeText.text = "🍽️ ${restaurant.type}"
            timeText.text = "⏰ Recoger entre: ${restaurant.generalPickupWindow}"

            if (cheapestPack != null) {
                val discountPercentage = ((cheapestPack.originalPrice - cheapestPack.discountPrice) / cheapestPack.originalPrice * 100).toInt()
                priceText.text = "💰 ~~$${cheapestPack.originalPrice.toInt()}~~ **$${cheapestPack.discountPrice.toInt()}** ($discountPercentage% OFF)"
            } else {
                priceText.text = "💰 Precios no disponibles"
            }

            packsText.text = "🎁 $totalPacks packs disponibles"

            restaurantView.setOnClickListener {
                Log.d(TAG, "Click en restaurante: ${restaurant.name}")

                ShoppingCartManager.switchToRestaurant(restaurant.id, restaurant.name)

                val intent = Intent(this@HomeActivity, RestaurantDetailActivity::class.java).apply {
                    putExtra("RESTAURANT", restaurant)
                    Log.d(TAG, "Intent creado para RestaurantDetailActivity")
                }
                startActivity(intent)
                Log.d(TAG, "Activity iniciada")
            }

            restaurantsLayout.addView(restaurantView)
        }
    }

    private fun showLocationOptions() {
        val options = arrayOf("Actualizar ubicación", "Buscar dirección", "Configurar ubicación manual")

        AlertDialog.Builder(this)
            .setTitle("Ubicación")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        // Actualizar ubicación
                        if (checkLocationPermission()) {
                            getLastKnownLocation()
                            Toast.makeText(this, "Actualizando ubicación...", Toast.LENGTH_SHORT).show()
                        } else {
                            requestLocationPermission()
                        }
                    }
                    1 -> {
                        //  dirección
                        showAddressSearchDialog()
                    }
                    2 -> {
                        // ubicación manual
                        showManualLocationDialog()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showAddressSearchDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_search_address, null)
        val editText = dialogView.findViewById<EditText>(R.id.addressEditText)

        AlertDialog.Builder(this)
            .setTitle("Buscar dirección")
            .setView(dialogView)
            .setPositiveButton("Buscar") { dialog, _ ->
                val address = editText.text.toString()
                if (address.isNotEmpty()) {
                    geocodeAddress(address)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showManualLocationDialog() {
        val locations = arrayOf(
            "Ciudad de México, MX",
            "Guadalajara, JAL",
            "Monterrey, NL",
            "Puebla, PUE",
            "Cancún, QR"
        )

        AlertDialog.Builder(this)
            .setTitle("Seleccionar ciudad")
            .setItems(locations) { dialog, which ->
                currentAddress = locations[which]
                findViewById<TextView>(R.id.locationText).text = currentAddress

                updateRestaurantsForCity(which)

                Toast.makeText(this, "Ubicación configurada: $currentAddress", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun updateRestaurantsForCity(cityIndex: Int) {
        // Coordenadas ficticias
        val cityCoordinates = listOf(
            Pair(19.4326, -99.1332), // CDMX
            Pair(20.6597, -103.3496), // Guadalajara
            Pair(25.6866, -100.3161), // Monterrey
            Pair(19.0414, -98.2063), // Puebla
            Pair(21.1619, -86.8515)  // Cancún
        )

        val (cityLat, cityLon) = cityCoordinates[cityIndex]

        val fakeLocation = Location("").apply {
            latitude = cityLat
            longitude = cityLon
        }
        currentLocation = fakeLocation

        updateRestaurantsWithRealDistance()
    }

    private fun geocodeAddress(address: String) {
        val geocoder = Geocoder(this, Locale.getDefault())

        try {
            val addresses = geocoder.getFromLocationName(address, 1)
            if (addresses != null && addresses.isNotEmpty()) {
                val location = addresses[0]
                currentLocation = Location("").apply {
                    latitude = location.latitude
                    longitude = location.longitude
                }
                updateLocationText(currentLocation!!)
                updateRestaurantsWithRealDistance()
                Toast.makeText(this, "Ubicación actualizada", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Dirección no encontrada", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            Toast.makeText(this, "Error buscando dirección", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    true
                }
                R.id.nav_search -> {
                    // Enfocar en la búsqueda cuando se seleccione la pestaña de búsqueda
                    searchEditText.requestFocus()
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    imm.showSoftInput(searchEditText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    true
                }
                R.id.nav_favorites -> {
                    val intent = Intent(this, FavoritesActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_orders -> {
                    val intent = Intent(this, OrdersActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupClickListeners() {
        val cartButton = findViewById<ImageView>(R.id.cartButton)
        val cartCount = findViewById<TextView>(R.id.cartCount)

        // contador del carrito
        updateCartCount(cartCount)

        cartButton.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }

        findViewById<ImageView>(R.id.notificationsButton).setOnClickListener {
            Toast.makeText(this, "Notificaciones", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageView>(R.id.filterButton).setOnClickListener {
            showFilterDialog()
        }
    }

    private fun updateCartCount(textView: TextView) {
        val totalItems = ShoppingCartManager.getTotalItemsCount()
        textView.text = totalItems.toString()
        textView.visibility = if (totalItems > 0) View.VISIBLE else View.INVISIBLE
    }

    private fun showFilterDialog() {
        val filterOptions = arrayOf("Todos", "Mexicana", "Italiana", "Japonesa", "China", "Rápida", "Postres", "Cercanos primero", "Mejor calificados")

        AlertDialog.Builder(this)
            .setTitle("Filtrar restaurantes")
            .setItems(filterOptions) { dialog, which ->
                val selectedFilter = filterOptions[which]

                when (selectedFilter) {
                    "Cercanos primero" -> {
                        // Ordenar por cercanía
                        if (currentLocation != null) {
                            filteredRestaurants.sortBy { restaurant ->
                                calculateDistance(
                                    currentLocation!!.latitude,
                                    currentLocation!!.longitude,
                                    restaurant.latitude,
                                    restaurant.longitude
                                )
                            }
                            displayRestaurants()
                        } else {
                            Toast.makeText(this, "Necesitamos tu ubicación para ordenar por cercanía", Toast.LENGTH_SHORT).show()
                        }
                    }
                    "Mejor calificados" -> {
                        // Ordenar por rating
                        filteredRestaurants.sortByDescending { it.rating }
                        displayRestaurants()
                    }
                    else -> {
                        // Filtrar por tipo de comida
                        currentCategoryFilter = selectedFilter
                        filteredRestaurants.clear()
                        if (selectedFilter == "Todos") {
                            filteredRestaurants.addAll(allRestaurants)
                        } else {
                            filteredRestaurants.addAll(allRestaurants.filter {
                                it.type.lowercase(Locale.getDefault()).contains(
                                    selectedFilter.lowercase(Locale.getDefault())
                                )
                            })
                        }
                        displayRestaurants()
                    }
                }

                Toast.makeText(this, "Filtro aplicado: $selectedFilter", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    override fun onResume() {
        super.onResume()
        if (checkLocationPermission()) {
            startLocationUpdates()
        }

        // Actualizar contador del carrito
        val cartCount = findViewById<TextView>(R.id.cartCount)
        updateCartCount(cartCount)

        // Actualizar lista de restaurantes
        displayRestaurants()
    }
}