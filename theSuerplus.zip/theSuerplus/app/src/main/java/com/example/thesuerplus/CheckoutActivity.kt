package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class CheckoutActivity : AppCompatActivity() { // Cambié el nombre a CheckoutActivity (sin typo)

    private lateinit var restaurantCart: RestaurantCart
    private var selectedPaymentMethod: String = "tarjeta"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurar Status Bar
        window.apply {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@CheckoutActivity, R.color.primary_dark)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }

        setContentView(R.layout.activity_checkout_activity)

        // Obtener el carrito del restaurante
        val restaurantId = intent.getStringExtra("RESTAURANT_ID")
        restaurantCart = ShoppingCartManager.getCartForRestaurant(restaurantId ?: "") ?: run {
            Toast.makeText(this, "Carrito vacío", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupToolbar()
        setupOrderSummary()
        setupPaymentMethods()
        setupPaymentForm()
        setupConfirmButton()
    }

    private fun setupToolbar() {
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
    }

    private fun setupOrderSummary() {
        val restaurantName = findViewById<TextView>(R.id.restaurantNameSummary)
        val subtotalText = findViewById<TextView>(R.id.subtotalText)
        val taxText = findViewById<TextView>(R.id.taxText)
        val deliveryText = findViewById<TextView>(R.id.deliveryText)
        val totalText = findViewById<TextView>(R.id.totalText)
        val itemsContainer = findViewById<LinearLayout>(R.id.itemsSummaryContainer)

        // Limpiar items anteriores
        itemsContainer.removeAllViews()

        // Mostrar restaurante
        restaurantName.text = restaurantCart.restaurantName

        // Calcular montos
        val subtotal = restaurantCart.totalPrice
        val tax = subtotal * 0.16 // 16% IVA
        val delivery = 15.0 // Costo fijo de entrega
        val total = subtotal + tax + delivery

        subtotalText.text = "$${String.format("%.2f", subtotal)}"
        taxText.text = "$${String.format("%.2f", tax)}"
        deliveryText.text = "$${String.format("%.2f", delivery)}"
        totalText.text = "$${String.format("%.2f", total)}"

        // Mostrar items
        restaurantCart.items.forEach { item ->
            val itemView = layoutInflater.inflate(R.layout.item_checkout_product, itemsContainer, false)

            // VERIFICA QUE ESTOS IDs EXISTAN EN TU item_checkout_product.xml
            // Si no existen, cambia estos IDs por los que tienes en tu layout
            val nameText = itemView.findViewById<TextView>(R.id.itemNameCheckout)
            val quantityText = itemView.findViewById<TextView>(R.id.itemQuantityCheckout)
            val priceText = itemView.findViewById<TextView>(R.id.itemPriceCheckout)

            nameText.text = item.packName
            quantityText.text = "x${item.quantity}"
            priceText.text = "$${String.format("%.2f", item.totalPrice)}"

            itemsContainer.addView(itemView)
        }
    }

    private fun setupPaymentMethods() {
        val cardMethod = findViewById<LinearLayout>(R.id.cardMethod)
        val cashMethod = findViewById<LinearLayout>(R.id.cashMethod)

        val cardCheck = findViewById<ImageView>(R.id.cardCheck)
        val cashCheck = findViewById<ImageView>(R.id.cashCheck)

        cardMethod.setOnClickListener {
            selectedPaymentMethod = "tarjeta"
            cardCheck.visibility = View.VISIBLE
            cashCheck.visibility = View.INVISIBLE
            findViewById<LinearLayout>(R.id.cardForm).visibility = View.VISIBLE
        }

        cashMethod.setOnClickListener {
            selectedPaymentMethod = "efectivo"
            cashCheck.visibility = View.VISIBLE
            cardCheck.visibility = View.INVISIBLE
            findViewById<LinearLayout>(R.id.cardForm).visibility = View.GONE
        }

        // Seleccionar tarjeta por defecto
        cardMethod.performClick()
    }

    private fun setupPaymentForm() {
        val cardNumber = findViewById<EditText>(R.id.cardNumberEditText)
        val cardExpiry = findViewById<EditText>(R.id.cardExpiryEditText)
        val cardCvv = findViewById<EditText>(R.id.cardCvvEditText)

        // Formatear número de tarjeta (XXXX XXXX XXXX XXXX)
        cardNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString().replace(" ", "")
                if (text.length > 0 && text.length % 4 == 0 && text.length < 16) {
                    cardNumber.setText("$text ")
                    cardNumber.setSelection(cardNumber.text.length)
                }
            }
        })

        // Formatear fecha (MM/YY) - CORREGIDO
        cardExpiry.addTextChangedListener(object : TextWatcher {
            private var isFormatting = false
            private var deletingBackslash = false

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                deletingBackslash = (count == 1 && s?.get(start) == '/')
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isFormatting) return

                isFormatting = true
                val text = s.toString()
                val cleaned = text.replace("/", "")

                if (deletingBackslash && text.endsWith("/")) {
                    // Si se está borrando la barra, quitarla
                    s?.replace(0, s.length, cleaned)
                } else if (cleaned.length == 2) {
                    // Si hay 2 dígitos, agregar la barra
                    s?.replace(0, s.length, "$cleaned/")
                }

                cardExpiry.setSelection(cardExpiry.text.length)
                isFormatting = false
            }
        })
    }

    private fun setupConfirmButton() {
        val confirmButton = findViewById<Button>(R.id.confirmPaymentButton)

        confirmButton.setOnClickListener {
            if (validateForm()) {
                processPayment()
            }
        }
    }

    private fun validateForm(): Boolean {
        if (selectedPaymentMethod == "tarjeta") {
            val cardNumber = findViewById<EditText>(R.id.cardNumberEditText).text.toString()
            val cardExpiry = findViewById<EditText>(R.id.cardExpiryEditText).text.toString()
            val cardCvv = findViewById<EditText>(R.id.cardCvvEditText).text.toString()

            if (cardNumber.replace(" ", "").length != 16) {
                Toast.makeText(this, "Número de tarjeta inválido", Toast.LENGTH_SHORT).show()
                return false
            }

            if (!cardExpiry.matches(Regex("\\d{2}/\\d{2}"))) {
                Toast.makeText(this, "Fecha de expiración inválida (formato: MM/YY)", Toast.LENGTH_SHORT).show()
                return false
            }

            if (cardCvv.length != 3) {
                Toast.makeText(this, "CVV inválido (deben ser 3 dígitos)", Toast.LENGTH_SHORT).show()
                return false
            }
        }

        return true
    }

    private fun processPayment() {
        // Mostrar progreso
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        progressBar.visibility = View.VISIBLE

        // Simular procesamiento de pago (2 segundos)
        Handler().postDelayed({
            progressBar.visibility = View.GONE

            // Crear orden
            val order = createOrder()

            // Guardar orden
            saveOrder(order)

            // Limpiar carrito de este restaurante
            ShoppingCartManager.removeCart(restaurantCart.restaurantId)

            // Mostrar confirmación
            showSuccessDialog(order)

        }, 2000)
    }

    private fun createOrder(): Order {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val currentDate = dateFormat.format(Date())

        // Generar número de orden aleatorio
        val orderNumber = (100000..999999).random().toString()

        // Crear items de la orden
        val orderItems = restaurantCart.items.map { item ->
            OrderItem(
                name = item.packName,
                quantity = item.quantity,
                price = item.unitPrice,
                total = item.totalPrice
            )
        }

        // Calcular totales
        val subtotal = restaurantCart.totalPrice
        val tax = subtotal * 0.16
        val delivery = 15.0
        val total = subtotal + tax + delivery

        return Order(
            orderId = generateOrderId(),
            restaurantId = restaurantCart.restaurantId,
            restaurantName = restaurantCart.restaurantName,
            restaurantImage = "", // Podrías guardar el resource ID como String
            items = orderItems,
            totalAmount = total,
            orderDate = currentDate,
            pickupTime = restaurantCart.items.firstOrNull()?.pickupWindow ?: "8:00 PM - 10:00 PM",
            status = if (selectedPaymentMethod == "efectivo") OrderStatus.PENDING else OrderStatus.CONFIRMED,
            paymentMethod = selectedPaymentMethod,
            orderNumber = orderNumber
        )
    }

    private fun generateOrderId(): String {
        return "ORD_${System.currentTimeMillis()}_${(1000..9999).random()}"
    }

    private fun saveOrder(order: Order) {
        val orders = OrdersManager.getOrders(this).toMutableList()
        orders.add(order)
        OrdersManager.saveOrders(this, orders)
    }

    private fun showSuccessDialog(order: Order) {
        AlertDialog.Builder(this)
            .setTitle("¡Pago Exitoso! 🎉")
            .setMessage("Tu orden #${order.orderNumber} ha sido confirmada.\n\n" +
                    "Recoger en: ${order.pickupTime}\n" +
                    "Total pagado: $${String.format("%.2f", order.totalAmount)}\n\n" +
                    "Gracias por tu compra. ¡Disfruta tu comida!")
            .setPositiveButton("Ver mis órdenes") { dialog, _ ->
                // Ir a OrdersActivity
                val intent = Intent(this, OrdersActivity::class.java)
                startActivity(intent)
                finishAffinity() // Cerrar todas las actividades anteriores
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }
}