package com.example.thesuerplus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class ProfileActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var btnLogout: Button
    private lateinit var btnBack: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Inicializar Firebase Auth
        auth = Firebase.auth

        // Inicializar vistas
        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        btnLogout = findViewById(R.id.btnLogout)
        btnBack = findViewById(R.id.btnBack)

        // Mostrar información del usuario actual
        mostrarInformacionUsuario()

        // Configurar botones
        configurarBotones()
    }

    private fun mostrarInformacionUsuario() {
        val user = auth.currentUser

        if (user != null) {
            // Mostrar nombre (si está disponible)
            val displayName = user.displayName ?: "Usuario"
            tvUserName.text = "Nombre: $displayName"

            // Mostrar email
            val email = user.email ?: "No disponible"
            tvUserEmail.text = "Email: $email"

            // Verificar si el email está verificado
            if (!user.isEmailVerified) {
                Toast.makeText(this, "Tu email no está verificado", Toast.LENGTH_SHORT).show()
            }
        } else {
            // Si no hay usuario, volver a MainActivity
            Toast.makeText(this, "No hay usuario autenticado", Toast.LENGTH_SHORT).show()
            irAMainActivity()
        }
    }

    private fun configurarBotones() {
        // Botón de retroceso
        btnBack.setOnClickListener {
            finish() // Regresa a la actividad anterior
        }

        // Botón de cerrar sesión
        btnLogout.setOnClickListener {
            cerrarSesion()
        }
    }

    private fun cerrarSesion() {
        // Cerrar sesión en Firebase
        auth.signOut()

        // También cerrar sesión de Google si se usó Google Sign-In
        try {
            GoogleSignIn.getClient(this,
                com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
                    com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN
                ).build()
            ).signOut()
        } catch (e: Exception) {
            // Ignorar si no está configurado
        }

        // Mostrar mensaje
        Toast.makeText(this, "Sesión cerrada exitosamente", Toast.LENGTH_SHORT).show()

        // Ir a MainActivity (portada)
        irAMainActivity()
    }

    private fun irAMainActivity() {
        val intent = Intent(this, MainActivity::class.java)

        // Flags para limpiar el stack de actividades
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(intent)
        finish() // Cerrar esta actividad
    }

    // Opcional: Si quieres verificar el estado de autenticación al iniciar
    override fun onStart() {
        super.onStart()
        val user = auth.currentUser
        if (user == null) {
            irAMainActivity()
        }
    }
}