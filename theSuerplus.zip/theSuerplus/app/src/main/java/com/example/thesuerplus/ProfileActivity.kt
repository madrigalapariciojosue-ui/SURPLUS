package com.example.thesuerplus

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import android.os.Build
import android.view.WindowManager
import java.text.NumberFormat
import java.util.*
class ProfileActivity : AppCompatActivity() {


    private lateinit var auth: FirebaseAuth
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvMemberSince: TextView
    private lateinit var tvOrdersCount: TextView
    private lateinit var tvSavedAmount: TextView
    private lateinit var userImageView: ImageView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurar Status Bar
        window.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@ProfileActivity, R.color.primary_dark)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }

        setContentView(R.layout.activity_profile)

        // Inicializar Firebase Auth
        auth = Firebase.auth

        // Inicializar vistas
        initViews()

        // Configurar navegación
        setupBottomNavigation()

        // Mostrar información del usuario
        loadUserData()
    }

    private fun initViews() {
        // Toolbar y navegación
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener { finish() }

        // Imagen de usuario
        userImageView = findViewById(R.id.userImage)
        userImageView.setOnClickListener {
            // Podrías agregar funcionalidad para cambiar foto
            Toast.makeText(this, "Función de cambiar foto en desarrollo", Toast.LENGTH_SHORT).show()
        }

        // TextViews
        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        tvMemberSince = findViewById(R.id.tvMemberSince)
        tvOrdersCount = findViewById(R.id.tvOrdersCount)
        tvSavedAmount = findViewById(R.id.tvSavedAmount)
        progressBar = findViewById(R.id.progressBar)

        // Configurar botones de opciones
        setupOptionButtons()
    }

    private fun setupOptionButtons() {
        // Editar perfil
        findViewById<LinearLayout>(R.id.optionEditProfile).setOnClickListener {
            showEditProfileDialog()
        }

        // Mis pedidos
        findViewById<LinearLayout>(R.id.optionMyOrders).setOnClickListener {
            val intent = Intent(this, OrdersActivity::class.java)
            startActivity(intent)
        }

        // Favoritos
        findViewById<LinearLayout>(R.id.optionFavorites).setOnClickListener {
            val intent = Intent(this, FavoritesActivity::class.java)
            startActivity(intent)
        }

        // Notificaciones
        findViewById<LinearLayout>(R.id.optionNotifications).setOnClickListener {
            showNotificationsSettings()
        }

        // Métodos de pago
        findViewById<LinearLayout>(R.id.optionPaymentMethods).setOnClickListener {
            Toast.makeText(this, "Gestión de métodos de pago en desarrollo", Toast.LENGTH_SHORT).show()
        }

        // Ayuda
        findViewById<LinearLayout>(R.id.optionHelp).setOnClickListener {
            showHelpDialog()
        }

        // Configuración
        findViewById<LinearLayout>(R.id.optionSettings).setOnClickListener {
            showSettingsDialog()
        }

        // Cerrar sesión
        findViewById<LinearLayout>(R.id.optionLogout).setOnClickListener {
            showLogoutConfirmation()
        }
    }

    private fun loadUserData() {
        val user = auth.currentUser

        if (user != null) {
            // Mostrar información del usuario
            val displayName = user.displayName ?: "Usuario"
            tvUserName.text = displayName
            tvUserEmail.text = user.email ?: "No disponible"

            // Fecha de creación de la cuenta
            val creationTime = user.metadata?.creationTimestamp ?: System.currentTimeMillis()
            val date = Date(creationTime)
            val dateFormat = android.text.format.DateFormat.getDateFormat(this)
            tvMemberSince.text = "Miembro desde: ${dateFormat.format(date)}"

            // Cargar imagen de perfil
            user.photoUrl?.let { photoUrl ->
                Glide.with(this)
                    .load(photoUrl)
                    .placeholder(R.drawable.ic_profile_placeholder)
                    .circleCrop()
                    .into(userImageView)
            }

            // Cargar estadísticas del usuario
            loadUserStatistics()

            // Ocultar progress bar
            progressBar.visibility = View.GONE
        } else {
            // Usuario no autenticado, volver a MainActivity
            Toast.makeText(this, "Por favor inicia sesión", Toast.LENGTH_SHORT).show()
            navigateToMainActivity()
        }
    }

    private fun loadUserStatistics() {
        // Aquí cargarías estadísticas reales desde Firebase o tu base de datos
        // Por ahora, datos de ejemplo

        val orders = OrdersManager.getOrders(this)
        val totalOrders = orders.size
        val totalSaved = orders.sumOf { it.totalAmount } * 0.3 // Simulando 30% de ahorro

        tvOrdersCount.text = "$totalOrders"

        val formatter = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        formatter.maximumFractionDigits = 2
        tvSavedAmount.text = formatter.format(totalSaved)
    }

    private fun showEditProfileDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_profile, null)

        val editName = dialogView.findViewById<EditText>(R.id.editName)
        val currentUser = auth.currentUser

        editName.setText(currentUser?.displayName ?: "")

        AlertDialog.Builder(this)
            .setTitle("Editar perfil")
            .setView(dialogView)
            .setPositiveButton("Guardar") { dialog, _ ->
                val newName = editName.text.toString().trim()
                if (newName.isNotEmpty() && newName != currentUser?.displayName) {
                    updateUserName(newName)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun updateUserName(newName: String) {
        progressBar.visibility = View.VISIBLE

        val user = auth.currentUser
        val profileUpdates = UserProfileChangeRequest.Builder()
            .setDisplayName(newName)
            .build()

        user?.updateProfile(profileUpdates)
            ?.addOnCompleteListener { task ->
                progressBar.visibility = View.GONE

                if (task.isSuccessful) {
                    tvUserName.text = newName
                    Toast.makeText(this, "Nombre actualizado", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al actualizar: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun showNotificationsSettings() {
        val notificationPrefs = getSharedPreferences("notifications", MODE_PRIVATE)
        val isEnabled = notificationPrefs.getBoolean("enabled", true)

        val items = arrayOf(
            "Notificaciones de nuevos packs",
            "Recordatorios de recogida",
            "Ofertas especiales",
            "Noticias de The Surplus"
        )

        val checkedItems = booleanArrayOf(
            notificationPrefs.getBoolean("new_packs", true),
            notificationPrefs.getBoolean("reminders", true),
            notificationPrefs.getBoolean("offers", true),
            notificationPrefs.getBoolean("news", true)
        )

        AlertDialog.Builder(this)
            .setTitle("Configurar notificaciones")
            .setMultiChoiceItems(items, checkedItems) { _, which, isChecked ->
                when (which) {
                    0 -> notificationPrefs.edit().putBoolean("new_packs", isChecked).apply()
                    1 -> notificationPrefs.edit().putBoolean("reminders", isChecked).apply()
                    2 -> notificationPrefs.edit().putBoolean("offers", isChecked).apply()
                    3 -> notificationPrefs.edit().putBoolean("news", isChecked).apply()
                }
            }
            .setPositiveButton("Guardar") { dialog, _ ->
                Toast.makeText(this, "Preferencias guardadas", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showHelpDialog() {
        AlertDialog.Builder(this)
            .setTitle("Ayuda y Soporte")
            .setMessage(
                "📞 **Atención al cliente:** 55-1234-5678\n\n" +
                        "📧 **Email:** soporte@thesurplus.com\n\n" +
                        "🕒 **Horario:** Lunes a Domingo 9:00 - 21:00\n\n" +
                        "📍 **Oficinas:** Av. Reforma 123, CDMX\n\n" +
                        "¿Necesitas ayuda con:\n" +
                        "• Tu pedido\n" +
                        "• Problemas de pago\n" +
                        "• Reembolsos\n" +
                        "• Sugerencias"
            )
            .setPositiveButton("Contactar") { dialog, _ ->
                val emailIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "message/rfc822"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("soporte@thesurplus.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "Ayuda - The Surplus App")
                }

                if (emailIntent.resolveActivity(packageManager) != null) {
                    startActivity(Intent.createChooser(emailIntent, "Enviar email"))
                } else {
                    Toast.makeText(this, "No hay aplicación de email instalada", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNeutralButton("FAQ") { dialog, _ ->
                // Podrías abrir una WebView o otra actividad con preguntas frecuentes
                Toast.makeText(this, "Preguntas frecuentes en desarrollo", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cerrar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showSettingsDialog() {
        val settingsPrefs = getSharedPreferences("app_settings", MODE_PRIVATE)

        val items = arrayOf(
            "Usar ubicación precisa",
            "Descargar imágenes solo en WiFi",
            "Auto-guardar pedidos",
            "Mostrar precios con IVA"
        )

        val checkedItems = booleanArrayOf(
            settingsPrefs.getBoolean("precise_location", true),
            settingsPrefs.getBoolean("wifi_only", true),
            settingsPrefs.getBoolean("auto_save", true),
            settingsPrefs.getBoolean("show_tax", true)
        )

        AlertDialog.Builder(this)
            .setTitle("Configuración de la app")
            .setMultiChoiceItems(items, checkedItems) { _, which, isChecked ->
                when (which) {
                    0 -> settingsPrefs.edit().putBoolean("precise_location", isChecked).apply()
                    1 -> settingsPrefs.edit().putBoolean("wifi_only", isChecked).apply()
                    2 -> settingsPrefs.edit().putBoolean("auto_save", isChecked).apply()
                    3 -> settingsPrefs.edit().putBoolean("show_tax", isChecked).apply()
                }
            }
            .setPositiveButton("Aplicar") { dialog, _ ->
                Toast.makeText(this, "Configuración aplicada", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showLogoutConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Cerrar sesión")
            .setMessage("¿Estás seguro de que quieres cerrar sesión?")
            .setPositiveButton("Sí, cerrar sesión") { dialog, _ ->
                performLogout()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun performLogout() {
        progressBar.visibility = View.VISIBLE

        auth.signOut()

        // Limpiar datos locales si es necesario
        FavoritesManager.clearFavorites(this)
        // No limpiamos órdenes para mantener historial

        progressBar.visibility = View.GONE

        Toast.makeText(this, "Sesión cerrada exitosamente", Toast.LENGTH_SHORT).show()
        navigateToMainActivity()
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun setupBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_profile

        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                    true
                }
                R.id.nav_search -> {
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("FOCUS_SEARCH", true)
                    startActivity(intent)
                    true
                }
                R.id.nav_favorites -> {
                    val intent = Intent(this, FavoritesActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_orders -> {
                    val intent = Intent(this, OrdersActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_profile -> {
                    // Ya estamos aquí
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadUserData()
    }
}