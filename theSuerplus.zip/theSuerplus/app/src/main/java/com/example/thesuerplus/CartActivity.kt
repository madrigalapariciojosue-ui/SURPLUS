package com.example.thesuerplus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

class CartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        setupToolbar()
        setupEmptyState()
        displayCartItems()
    }

    private fun setupToolbar() {
        val backButton = findViewById<ImageView>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        val clearAllButton = findViewById<TextView>(R.id.clearAllButton)
        clearAllButton.setOnClickListener {
            showClearAllDialog()
        }
    }

    private fun setupEmptyState() {
        val emptyCartView = findViewById<LinearLayout>(R.id.emptyCartView)
        val cartContent = findViewById<LinearLayout>(R.id.cartContent)
        val continueShoppingButton = findViewById<TextView>(R.id.continueShoppingButton)

        continueShoppingButton.setOnClickListener {
            finish()
        }

        if (!ShoppingCartManager.hasItemsInCart()) {
            emptyCartView.visibility = View.VISIBLE
            cartContent.visibility = View.GONE
        } else {
            emptyCartView.visibility = View.GONE
            cartContent.visibility = View.VISIBLE
        }
    }

    private fun displayCartItems() {
        val cartContainer = findViewById<LinearLayout>(R.id.cartContainer)
        val cartSummary = findViewById<LinearLayout>(R.id.cartSummary)
        val totalItemsText = findViewById<TextView>(R.id.totalItemsText)
        val totalPriceText = findViewById<TextView>(R.id.totalPriceText)

        cartContainer.removeAllViews()

        val restaurantCarts = ShoppingCartManager.getRestaurantsWithItems()

        if (restaurantCarts.isEmpty()) {
            setupEmptyState()
            return
        }

        var totalItems = 0
        var totalPrice = 0.0

        // Mostrar cada restaurante
        restaurantCarts.forEach { restaurantCart ->
            val restaurantSection = createRestaurantSection(restaurantCart)
            cartContainer.addView(restaurantSection)

            totalItems += restaurantCart.itemCount
            totalPrice += restaurantCart.totalPrice
        }

        // Mostrar resumen general
        totalItemsText.text = "Total: $totalItems items"
        totalPriceText.text = "$${String.format("%.2f", totalPrice)}"

        // Mostrar advertencia para diferentes restaurantes
        if (restaurantCarts.size > 1) {
            val warningView = LayoutInflater.from(this)
                .inflate(R.layout.item_cart_warning, cartContainer, false)

            warningView.findViewById<TextView>(R.id.warningText).text =
                "Tienes productos de ${restaurantCarts.size} restaurantes diferentes. " +
                        "Debes proceder al pago por separado para cada uno."

            cartContainer.addView(warningView, 0)
        }
    }

    private fun createRestaurantSection(restaurantCart: RestaurantCart): View {
        val restaurantView = LayoutInflater.from(this)
            .inflate(R.layout.item_cart_restaurant, null)

        // ebcanbezado
        val restaurantName = restaurantView.findViewById<TextView>(R.id.restaurantName)
        val itemCount = restaurantView.findViewById<TextView>(R.id.restaurantItemCount)
        val removeRestaurantButton = restaurantView.findViewById<ImageView>(R.id.removeRestaurantButton)

        restaurantName.text = restaurantCart.restaurantName
        itemCount.text = "${restaurantCart.itemCount} items"

        // botonsito para eliminar los restaurante o todo
        removeRestaurantButton.setOnClickListener {
            showRemoveRestaurantDialog(restaurantCart.restaurantId)
        }

        // Contenedor de items
        val itemsContainer = restaurantView.findViewById<LinearLayout>(R.id.restaurantItemsContainer)


        restaurantCart.items.forEach { cartItem ->
            val itemView = createCartItemView(cartItem, restaurantCart.restaurantId)
            itemsContainer.addView(itemView)
        }

        // Configurar subtotal y botones
        val subtotalText = restaurantView.findViewById<TextView>(R.id.restaurantSubtotal)
        val viewRestaurantButton = restaurantView.findViewById<TextView>(R.id.viewRestaurantButton)
        val checkoutButton = restaurantView.findViewById<TextView>(R.id.checkoutButton)

        subtotalText.text = "Subtotal: $${String.format("%.2f", restaurantCart.totalPrice)}"

        // Botón "Ver tienda" (podría redirigir al restaurante, mas adelante se configurara)
        viewRestaurantButton.setOnClickListener {
            Toast.makeText(this, "Para ver más productos, regresa al restaurante desde la página principal", Toast.LENGTH_SHORT).show()
        }

        // Botón "Pagar" para este restaurante, sencillito
        checkoutButton.setOnClickListener {
            startCheckoutForRestaurant(restaurantCart)
        }

        return restaurantView
    }

    private fun createCartItemView(cartItem: CartItem, restaurantId: String): View {
        val itemView = LayoutInflater.from(this)
            .inflate(R.layout.item_cart_product, null)

        // Obtener referencias
        val itemImage = itemView.findViewById<ImageView>(R.id.itemImage)
        val itemName = itemView.findViewById<TextView>(R.id.itemName)
        val itemDescription = itemView.findViewById<TextView>(R.id.itemDescription)
        val itemPrice = itemView.findViewById<TextView>(R.id.itemPrice)
        val quantityText = itemView.findViewById<TextView>(R.id.quantityText)
        val itemTotal = itemView.findViewById<TextView>(R.id.itemTotal)
        val decreaseButton = itemView.findViewById<ImageView>(R.id.decreaseButton)
        val increaseButton = itemView.findViewById<ImageView>(R.id.increaseButton)
        val removeButton = itemView.findViewById<ImageView>(R.id.removeButton)

        // Configurar datos
        itemImage.setImageResource(cartItem.packImageRes)
        itemName.text = cartItem.packName
        itemDescription.text = cartItem.packContents.joinToString(", ").take(50) + "..."
        itemPrice.text = "$${String.format("%.2f", cartItem.unitPrice)} c/u"
        quantityText.text = cartItem.quantity.toString()
        itemTotal.text = "$${String.format("%.2f", cartItem.totalPrice)}"

        // Botones de cantidad
        decreaseButton.setOnClickListener {
            val currentQuantity = cartItem.quantity
            if (currentQuantity > 1) {
                ShoppingCartManager.getCartForRestaurant(restaurantId)?.updateQuantity(
                    cartItem.packId,
                    currentQuantity - 1
                )
                refreshCartDisplay()
            }
        }

        increaseButton.setOnClickListener {
            ShoppingCartManager.getCartForRestaurant(restaurantId)?.updateQuantity(
                cartItem.packId,
                cartItem.quantity + 1
            )
            refreshCartDisplay()
        }

        // Botón eliminar
        removeButton.setOnClickListener {
            ShoppingCartManager.getCartForRestaurant(restaurantId)?.removeItem(cartItem.packId)
            refreshCartDisplay()
        }

        return itemView
    }

    private fun startCheckoutForRestaurant(restaurantCart: RestaurantCart) {
        AlertDialog.Builder(this)
            .setTitle("Proceder al pago")
            .setMessage("¿Deseas proceder al pago de ${restaurantCart.itemCount} items de ${restaurantCart.restaurantName} por un total de $${String.format("%.2f", restaurantCart.totalPrice)}?")
            .setPositiveButton("Sí, pagar") { dialog, _ ->
                Toast.makeText(this, "Funcionalidad de pago en desarrollo", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showClearAllDialog() {
        AlertDialog.Builder(this)
            .setTitle("Vaciar carrito")
            .setMessage("¿Estás seguro de que quieres eliminar todos los productos del carrito?")
            .setPositiveButton("Sí, vaciar") { dialog, _ ->
                ShoppingCartManager.getAllCarts().forEach { cart ->
                    ShoppingCartManager.removeCart(cart.restaurantId)
                }
                refreshCartDisplay()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showRemoveRestaurantDialog(restaurantId: String) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar restaurante")
            .setMessage("¿Eliminar todos los productos de este restaurante del carrito?")
            .setPositiveButton("Eliminar") { dialog, _ ->
                ShoppingCartManager.removeCart(restaurantId)
                refreshCartDisplay()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun refreshCartDisplay() {
        displayCartItems()
        setupEmptyState()
    }

    override fun onResume() {
        super.onResume()
        refreshCartDisplay()
    }
}