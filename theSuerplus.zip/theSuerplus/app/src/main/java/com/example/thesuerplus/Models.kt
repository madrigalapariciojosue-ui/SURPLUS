package com.example.thesuerplus

import android.content.Context

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.Serializable


data class Restaurant(
    val id: String,
    val name: String,
    val type: String,
    val rating: Double,
    val reviewCount: Int,
    var distance: String,
    val imageRes: Int,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val generalPickupWindow: String = "8:00 PM - 10:00 PM",
    val packs: List<Pack> = emptyList()
) : Serializable

data class Pack(
    val id: String,
    val name: String,
    val description: String,
    val contents: List<String>,
    val originalPrice: Double,
    val discountPrice: Double,
    val availableQuantity: Int,
    val category: String,
    val pickupWindow: String,
    val imageRes: Int
) : Serializable {
    val discountPercentage: Int
        get() = ((originalPrice - discountPrice) / originalPrice * 100).toInt()
}

// Item individual del carrito
data class CartItem(
    val restaurantId: String,
    val restaurantName: String,
    val packId: String,
    val packName: String,
    val quantity: Int,
    val unitPrice: Double,
    val pickupWindow: String,
    val packContents: List<String>,
    val packImageRes: Int
) : Serializable {
    val totalPrice: Double
        get() = unitPrice * quantity
}
data class Order(
    val orderId: String = "",
    val restaurantId: String = "",
    val restaurantName: String = "",
    val restaurantImage: String = "",
    val items: List<OrderItem> = emptyList(),
    val totalAmount: Double = 0.0,
    val orderDate: String = "",
    val pickupTime: String = "",
    val status: OrderStatus = OrderStatus.PENDING,
    val paymentMethod: String = "",
    val orderNumber: String = ""
)

data class OrderItem(
    val name: String = "",
    val quantity: Int = 1,
    val price: Double = 0.0,
    val total: Double = 0.0
)

enum class OrderStatus {
    PENDING, CONFIRMED, PREPARING, READY, COMPLETED, CANCELLED
}

// Carrito por restaurante
data class RestaurantCart(
    val restaurantId: String,
    val restaurantName: String,
    val items: MutableList<CartItem> = mutableListOf()
) : Serializable {
    val totalPrice: Double
        get() = items.sumOf { it.totalPrice }

    val itemCount: Int
        get() = items.sumOf { it.quantity }

    fun addItem(item: CartItem) {
        val existingIndex = items.indexOfFirst { it.packId == item.packId }

        if (existingIndex != -1) {
            val existingItem = items[existingIndex]
            items[existingIndex] = existingItem.copy(
                quantity = existingItem.quantity + item.quantity
            )
        } else {
            items.add(item)
        }
    }

    fun removeItem(packId: String) {
        items.removeAll { it.packId == packId }
    }

    fun updateQuantity(packId: String, newQuantity: Int) {
        val index = items.indexOfFirst { it.packId == packId }
        if (index != -1 && newQuantity > 0) {
            items[index] = items[index].copy(quantity = newQuantity)
        } else if (newQuantity <= 0) {
            removeItem(packId)
        }
    }

    fun clear() {
        items.clear()
    }
}

// Gestor global de carritos
object ShoppingCartManager {
    private val restaurantCarts = mutableMapOf<String, RestaurantCart>()
    private var currentRestaurantId: String? = null

    // Cambiar al carrito de un restaurante
    fun switchToRestaurant(restaurantId: String, restaurantName: String) {
        currentRestaurantId = restaurantId
        if (!restaurantCarts.containsKey(restaurantId)) {
            restaurantCarts[restaurantId] = RestaurantCart(restaurantId, restaurantName)
        }
    }

    // Obtener carrito actual
    fun getCurrentCart(): RestaurantCart? {
        return currentRestaurantId?.let { restaurantCarts[it] }
    }

    // Obtener carrito de un restaurante específico
    fun getCartForRestaurant(restaurantId: String): RestaurantCart? {
        return restaurantCarts[restaurantId]
    }

    // Agregar item al carrito actual
    fun addItemToCurrentCart(item: CartItem) {
        val cart = getCurrentCart()
        cart?.addItem(item)
    }

    // Obtener todos los carritos
    fun getAllCarts(): List<RestaurantCart> {
        return restaurantCarts.values.toList()
    }

    // Obtener solo los carritos que tienen items
    fun getRestaurantsWithItems(): List<RestaurantCart> {
        return restaurantCarts.values.filter { it.itemCount > 0 }
    }

    // Limpiar carrito actual
    fun clearCurrentCart() {
        getCurrentCart()?.clear()
    }

    // Eliminar carrito de un restaurante
    fun removeCart(restaurantId: String) {
        restaurantCarts.remove(restaurantId)
        if (currentRestaurantId == restaurantId) {
            currentRestaurantId = null
        }
    }

    // Contar total de items en todos los carritos
    fun getTotalItemsCount(): Int {
        return restaurantCarts.values.sumOf { it.itemCount }
    }

    // Calcular precio total de todos los carritos
    fun getTotalPrice(): Double {
        return restaurantCarts.values.sumOf { it.totalPrice }
    }

    // Verificar si hay items de múltiples restaurantes
    fun hasItemsFromMultipleRestaurants(): Boolean {
        return restaurantCarts.values.count { it.itemCount > 0 } > 1
    }

    // Verificar si hay items en algún carrito
    fun hasItemsInCart(): Boolean {
        return restaurantCarts.values.any { it.itemCount > 0 }
    }
}

// Sistema de gestión de favoritos
object FavoritesManager {
    private const val PREF_NAME = "favorites_prefs"
    private const val KEY_FAVORITES = "favorite_restaurants"
    private val gson = Gson()

    // Guardar un restaurante como favorito
    fun addFavorite(context: Context, restaurant: Restaurant) {
        val favorites = getFavorites(context).toMutableList()

        // Verificar si ya existe
        if (!favorites.any { it.id == restaurant.id }) {
            favorites.add(restaurant)
            saveFavorites(context, favorites)
        }
    }

    // Remover un restaurante de favoritos
    fun removeFavorite(context: Context, restaurantId: String) {
        val favorites = getFavorites(context).toMutableList()
        favorites.removeAll { it.id == restaurantId }
        saveFavorites(context, favorites)
    }

    // Verificar si un restaurante es favorito
    fun isFavorite(context: Context, restaurantId: String): Boolean {
        return getFavorites(context).any { it.id == restaurantId }
    }

    // Obtener todos los favoritos
    fun getFavorites(context: Context): List<Restaurant> {
        val sharedPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = sharedPref.getString(KEY_FAVORITES, "[]")

        return try {
            val type = object : TypeToken<List<Restaurant>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Obtener todos los IDs de favoritos
    fun getFavoriteIds(context: Context): List<String> {
        return getFavorites(context).map { it.id }
    }

    // Limpiar todos los favoritos
    fun clearFavorites(context: Context) {
        val sharedPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        sharedPref.edit().remove(KEY_FAVORITES).apply()
    }

    // Contar favoritos
    fun getFavoriteCount(context: Context): Int {
        return getFavorites(context).size
    }

    private fun saveFavorites(context: Context, favorites: List<Restaurant>) {
        val sharedPref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = gson.toJson(favorites)
        sharedPref.edit().putString(KEY_FAVORITES, json).apply()
    }
}