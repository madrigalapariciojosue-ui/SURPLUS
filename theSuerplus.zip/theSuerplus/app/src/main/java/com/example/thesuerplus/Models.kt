package com.example.thesuerplus

import java.io.Serializable
data class Restaurant(
    val id: String,
    val name: String,
    val type: String,
    val rating: Double,
    val reviewCount: Int,
    var distance: String,
    val imageRes: Int,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val generalPickupWindow: String = "8:00 PM - 10:00 PM",
    val packs: List<Pack> = emptyList()
) : Serializable

data class Pack(
    val id: String,
    val name: String,
    val description: String,
    val contents: List<String>,
    val originalPrice: Double,
    val discountPrice: Double,
    val availableQuantity: Int,
    val category: String,
    val pickupWindow: String,
    val imageRes: Int
) : Serializable {
    val discountPercentage: Int
        get() = ((originalPrice - discountPrice) / originalPrice * 100).toInt()
}

// Item individual del carrito
data class CartItem(
    val restaurantId: String,
    val restaurantName: String,
    val packId: String,
    val packName: String,
    val quantity: Int,
    val unitPrice: Double,
    val pickupWindow: String,
    val packContents: List<String>,
    val packImageRes: Int
) : Serializable {
    val totalPrice: Double
        get() = unitPrice * quantity
}

// Carrito por restaurante
data class RestaurantCart(
    val restaurantId: String,
    val restaurantName: String,
    val items: MutableList<CartItem> = mutableListOf()
) : Serializable {
    val totalPrice: Double
        get() = items.sumOf { it.totalPrice }

    val itemCount: Int
        get() = items.sumOf { it.quantity }

    fun addItem(item: CartItem) {
        val existingIndex = items.indexOfFirst { it.packId == item.packId }

        if (existingIndex != -1) {
            val existingItem = items[existingIndex]
            items[existingIndex] = existingItem.copy(
                quantity = existingItem.quantity + item.quantity
            )
        } else {
            items.add(item)
        }
    }

    fun removeItem(packId: String) {
        items.removeAll { it.packId == packId }
    }

    fun updateQuantity(packId: String, newQuantity: Int) {
        val index = items.indexOfFirst { it.packId == packId }
        if (index != -1 && newQuantity > 0) {
            items[index] = items[index].copy(quantity = newQuantity)
        } else if (newQuantity <= 0) {
            removeItem(packId)
        }
    }

    fun clear() {
        items.clear()
    }
}

// Gestor global de carritos
object ShoppingCartManager {
    private val restaurantCarts = mutableMapOf<String, RestaurantCart>()
    private var currentRestaurantId: String? = null

    // Cambiar al carrito de un restaurante
    fun switchToRestaurant(restaurantId: String, restaurantName: String) {
        currentRestaurantId = restaurantId
        if (!restaurantCarts.containsKey(restaurantId)) {
            restaurantCarts[restaurantId] = RestaurantCart(restaurantId, restaurantName)
        }
    }

    // Obtener carrito actual
    fun getCurrentCart(): RestaurantCart? {
        return currentRestaurantId?.let { restaurantCarts[it] }
    }

    // Obtener carrito de un restaurante específico
    fun getCartForRestaurant(restaurantId: String): RestaurantCart? {
        return restaurantCarts[restaurantId]
    }

    // Agregar item al carrito actual
    fun addItemToCurrentCart(item: CartItem) {
        val cart = getCurrentCart()
        cart?.addItem(item)
    }

    // Obtener todos los carritos
    fun getAllCarts(): List<RestaurantCart> {
        return restaurantCarts.values.toList()
    }

    // Obtener solo los carritos que tienen items
    fun getRestaurantsWithItems(): List<RestaurantCart> {
        return restaurantCarts.values.filter { it.itemCount > 0 }
    }

    // Limpiar carrito actual
    fun clearCurrentCart() {
        getCurrentCart()?.clear()
    }

    // Eliminar carrito de un restaurante
    fun removeCart(restaurantId: String) {
        restaurantCarts.remove(restaurantId)
        if (currentRestaurantId == restaurantId) {
            currentRestaurantId = null
        }
    }

    // Contar total de items en todos los carritos
    fun getTotalItemsCount(): Int {
        return restaurantCarts.values.sumOf { it.itemCount }
    }

    // Calcular precio total de todos los carritos
    fun getTotalPrice(): Double {
        return restaurantCarts.values.sumOf { it.totalPrice }
    }

    // Verificar si hay items de múltiples restaurantes
    fun hasItemsFromMultipleRestaurants(): Boolean {
        return restaurantCarts.values.count { it.itemCount > 0 } > 1
    }

    // Verificar si hay items en algún carrito
    fun hasItemsInCart(): Boolean {
        return restaurantCarts.values.any { it.itemCount > 0 }
    }
}