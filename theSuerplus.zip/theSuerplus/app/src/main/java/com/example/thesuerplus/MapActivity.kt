package com.example.thesuerplus

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private var userLatitude: Double = 0.0
    private var userLongitude: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        // Obtener ubicación
        userLatitude = intent.getDoubleExtra("latitude", 19.4326)
        userLongitude = intent.getDoubleExtra("longitude", -99.1332)

        // Configurar mapa
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Configurar ubicación
        val userLocation = LatLng(userLatitude, userLongitude)
        googleMap.addMarker(
            MarkerOptions()
                .position(userLocation)
                .title("Tu ubicación")
        )

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15f))

        addRestaurantMarkers()
    }

    private fun addRestaurantMarkers() {
        }
}