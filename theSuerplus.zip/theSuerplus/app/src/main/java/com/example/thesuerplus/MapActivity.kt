package com.example.thesuerplus

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import android.os.Build
import androidx.core.content.ContextCompat
import android.view.WindowManager
import android.view.View
class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private var userLatitude: Double = 0.0
    private var userLongitude: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.apply {
            // Para Android 5.0+ (API 21+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = ContextCompat.getColor(this@MapActivity, R.color.primary_dark)
            }

            // Para Android 6.0+ (íconos claros u oscuros)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        setContentView(R.layout.activity_map)

        // Obtener ubicación
        userLatitude = intent.getDoubleExtra("latitude", 19.4326)
        userLongitude = intent.getDoubleExtra("longitude", -99.1332)

        // Configurar mapa
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Configurar ubicación
        val userLocation = LatLng(userLatitude, userLongitude)
        googleMap.addMarker(
            MarkerOptions()
                .position(userLocation)
                .title("Tu ubicación")
        )

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15f))

        addRestaurantMarkers()
    }

    private fun addRestaurantMarkers() {
        }
}